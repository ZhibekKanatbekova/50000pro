
let numberOfStars = document.getElementsByClassName("star").length;
for (let i = 0; i < numberOfStars; i++) {
  document.getElementsByClassName("star")[i].addEventListener("click", function changeImg() {
    let buttonColor = this.src = "images/star.png"
    return buttonColor
    });
}

// let numberOfStars = document.getElementsByClassName("star").length;
// for (let i = 0; i < numberOfStars; i++) {
//   document.getElementsByClassName("star")[i].addEventListener("click", function changeImg() {
//      let buttonColor = this.src
// if (buttonColor == "images/star-regular.svg") {
//    buttonColor = "images/star.png"
// } else {
//    buttonColor = "images/star-regular.svg";
// }
// return buttonColor
// })}